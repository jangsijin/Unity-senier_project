﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickButton: MonoBehaviour {

    // Use this for initialization

    public int Health = 25;
    public int Dmg = 2;
    public int count = 15;


    public void onClick()
    {
        onDamage();        
    }

    public void onDamage()
    {
        Health = Health - Dmg;
        if (Health <= 0)
            onDie();
        count--;

            
    }

    public void onDie()
    {
        Debug.Log("고블린이 죽었어요");
    }

}
